$(function() {
	$('#update').attr('disabled', true);
});
function check() {
	var id_check = $("#id").val().length;
	if (id_check <= 5) {
		$("#id_check").text("아이디는 5글자 이상 적어주세요.");
		$('#update').attr('disabled', true);
	} else {
		$("#id_check").text("아이디가 5글자 이상입니다.");
		$('#update').attr('disabled', false);
	}
}
