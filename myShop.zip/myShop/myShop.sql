create database myshop;

create table product(
	id varchar(30) not null primary key,
	title varchar(100) not null,
	content varchar(100) not null,
	price varchar(100) not null
);