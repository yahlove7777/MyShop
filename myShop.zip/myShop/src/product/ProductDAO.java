package product;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

public class ProductDAO {
	DBConnectionMgr mgr;

	public ProductDAO() {
		mgr = DBConnectionMgr.getInstance();
	}

	public ArrayList<ProductDTO> selectAll() throws Exception {
		ArrayList<ProductDTO> list = new ArrayList<ProductDTO>();
		// 1, 2단계를 해주는 DBConnectionMgr 객체 필요
		Connection con = mgr.getConnection();

		// 3단계 sql문 결정
		String sql = "select * from product";
		PreparedStatement ps = con.prepareStatement(sql);

		// 4단계 sql문 전달 요청
		ResultSet rs = ps.executeQuery();
		ProductDTO dto2 = null;

		while (rs.next()) {
			dto2 = new ProductDTO();
			String id = rs.getString(1);
			String title = rs.getString(2);
			String content = rs.getString(3);
			String price = rs.getString(4);

			dto2.setId(id);
			dto2.setTitle(title);
			dto2.setContent(content);
			dto2.setPrice(price);
			list.add(dto2);
		}
		mgr.freeConnection(con, ps, rs);
		return list;
	}

	public void insert(String id, String title, String content, String price) throws Exception {
		// 1, 2단계를 해주는 DBConnectionMgr 객체 필요

		Connection con = mgr.getConnection();

		// 3단계 sql문 결정
		String sql = "insert into product values (?, ?, ?, ?)";
		PreparedStatement ps = con.prepareStatement(sql);
		ps.setString(1, id);
		ps.setString(2, title);
		ps.setString(3, content);
		ps.setString(4, price);

		// 4단계 sql문 전달 요청
		ps.executeUpdate();

		// select 의 경우 rs까지 입력
		mgr.freeConnection(con, ps);

	}

	public void update(ProductDTO dto) throws Exception {
		// 1, 2단계를 해주는 DBConnectionMgr 객체 필요

		Connection con = mgr.getConnection();

		// 3단계 sql문 결정
		String sql = "update product set title=?, content=?, price=? where id = ?";
		PreparedStatement ps = con.prepareStatement(sql);
		ps.setString(1, dto.getTitle());
		ps.setString(2, dto.getContent());
		ps.setString(3, dto.getPrice());
		ps.setString(4, dto.getId());

		// 4단계 sql문 전달 요청
		ps.executeUpdate();
		mgr.freeConnection(con, ps);
	}

	/** 한사람의 회원 정보를 얻는 메소드 */
	public ProductDTO getMemberDTO(String id) throws Exception {

		ProductDTO dto = new ProductDTO();

		PreparedStatement ps = null; // 명령
		ResultSet rs = null; // 결과

		Connection con = mgr.getConnection();
		String sql = "select * from product where id=?";
		ps = con.prepareStatement(sql);
		ps.setString(1, id);

		rs = ps.executeQuery();

		if (rs.next()) {
			dto.setId(rs.getString("id"));
			dto.setTitle(rs.getString("title"));
			dto.setContent(rs.getString("content"));
			dto.setPrice(rs.getString("price"));
		}
		mgr.freeConnection(con, ps, rs);
		return dto;

	}
	/**회원정보 삭제 :
     *tip: 실무에서는 회원정보를 Delete 하지 않고 탈퇴여부만 체크한다.*/
    public int delete(String id)  throws Exception{
       

        Connection con =null;
        PreparedStatement ps =null;
       
    		con = mgr.getConnection();
            String sql = "delete from product where id=?";
           
            ps = con.prepareStatement(sql);
            ps.setString(1, id);
       
            return ps.executeUpdate(); // 실행 -> 삭제

    }
}
